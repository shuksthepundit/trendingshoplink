# Trending Kenya — backend

A small Node.js/Express service that polls a real news API and Google's Daily Trends
feed for Kenya on a schedule, caches the results, and serves them at `GET /api/trending`
for the Trending Kenya frontend to fetch.

This has to run somewhere outside the Claude.ai artifact preview — a browser-rendered
artifact can't run a persistent server or a cron schedule. Run it locally, on a small
VPS, or on a free host (Render, Railway, Fly.io all work fine for something this size).

## What it actually does

- **News** — polls [NewsData.io](https://newsdata.io) (or [GNews](https://gnews.io) as
  an alternative) for Kenya headlines across Politics, Business, Sports, Entertainment
  and Health, every `POLL_CRON_NEWS` interval (default: every 30 minutes).
- **Trending searches** — polls Google's Daily Trends RSS feed for Kenya
  (`trends.google.com/trending/rss?geo=KE`) every `POLL_CRON_TRENDS` interval (default:
  hourly). This is a real feed Google serves for this exact purpose — not the same
  thing as scraping a search-results page.
- **Daily snapshot** — once a day (`DAILY_SNAPSHOT_CRON`, default 06:00
  `DAILY_SNAPSHOT_TZ`/Africa/Nairobi), captures whatever's currently in the rolling
  cache above as the one official "today's trending" list and files it under
  `data/history/YYYY-MM-DD.json`. This is the automatic "capture new daily trends and
  update what's trending daily" layer: the rolling pollers keep individual stories
  fresh through the day, and this snapshot is the published daily digest built from
  them, the way a real trends site works. If nothing has captured a snapshot for the
  current day yet (server just started, or the scheduled time hasn't hit), the first
  request to `/api/trending/today` captures one on the spot — and if the rolling cache
  is still empty at that moment (e.g. seconds after boot, before the first poll
  resolves), it does NOT lock in a permanently-empty day — it retries on the next
  request instead.
- Caches everything in memory and on disk (`data/`), so a restart still has
  last-known-good data while waiting for the next poll or snapshot.

## API

| Route | Returns |
|---|---|
| `GET /api/trending` | The rolling cache (refreshed every 30–60 min) — "what's trending right now" |
| `GET /api/trending/today` | Today's captured snapshot: `{ date, capturedAt, stories }` — "today's trending," auto-captured if not yet taken |
| `GET /api/trending/history?date=YYYY-MM-DD` | A past day's snapshot, or `404` if none was captured that day |
| `GET /api/trending/history` | `{ dates: [...] }` — every date with a snapshot on file, newest first |
| `GET /api/health` | Status, last-poll timestamps/errors, and the configured daily-snapshot schedule |

The frontend (`trending_kenya_shoplink.jsx`) reads `/api/trending/today` by default.

## Setup

```bash
npm install
cp .env.example .env
```

Edit `.env`:

1. **Get a news API key.** Sign up free at either:
   - [newsdata.io](https://newsdata.io/register) — set `NEWS_PROVIDER=newsdata`
   - [gnews.io](https://gnews.io/register) — set `NEWS_PROVIDER=gnews`

   Paste the key into `NEWS_API_KEY`.
2. Leave `TRENDS_GEO=KE` as-is, or set `ENABLE_TRENDS_FEED=false` if you'd rather skip
   the Trends feed entirely (see the caveat below).
3. Adjust `POLL_CRON_NEWS` / `POLL_CRON_TRENDS` to fit your API plan's rate limit — the
   defaults are conservative for a free tier.
4. Adjust `DAILY_SNAPSHOT_CRON` / `DAILY_SNAPSHOT_TZ` if you want the daily capture to
   run at a different time or in a different timezone than 06:00 Africa/Nairobi.

Test your key without starting the full server:

```bash
npm run poll-once
```

Run the server:

```bash
npm start          # production
npm run dev         # auto-restarts on file changes
```

It listens on `PORT` (default `8787`). Check it's alive:

```bash
curl http://localhost:8787/api/health
curl http://localhost:8787/api/trending
curl http://localhost:8787/api/trending/today
curl http://localhost:8787/api/trending/history
```

## Deploying

Any Node 18+ host works. Quick options:

- **Render / Railway / Fly.io** — connect the repo, set the same env vars in their
  dashboard, `npm start` as the start command. All three have a free tier sufficient
  for this.
- **Your own VPS** — run it behind `pm2` or a `systemd` unit so it survives reboots.

Once deployed, set `ALLOWED_ORIGINS` to your actual frontend domain (not `*`) so
random sites can't read your API quota.

## Known limitation: the Google Trends feed can be blocked

While building this, a direct test of `trends.google.com/trending/rss` returned a
`403` from Google's own server — this can happen from certain hosting/cloud IP ranges
that Google's bot protection flags, independent of anything wrong in the code. Whether
it works for you depends on where you deploy:

- It often works fine from a residential IP or some cloud regions, and may still get
  blocked from others (shared hosting IPs get flagged more often).
- If it's unreliable in your deployment, set `ENABLE_TRENDS_FEED=false` in `.env` — the
  news poller keeps working independently, and the frontend's curated fallback data
  covers the "Trending Searches" category in the meantime.
- If you need that category reliably, the more robust (but paid) route is a proper
  trends data provider, or X/Twitter's API if you have access to it.

The news polling (NewsData/GNews) does not have this issue — it's a normal
authenticated API call, not a public feed subject to bot-detection.

## Connecting the frontend

In `trending_kenya_shoplink.jsx`, set:

```js
const BACKEND_URL = "https://your-deployed-backend.example.com";
```

The frontend fetches `${BACKEND_URL}/api/trending` on load and on manual refresh. If
the fetch fails (backend not deployed yet, CORS misconfigured, etc.) it falls back to
the curated local dataset automatically — the page never breaks or shows blank.

**Note on the Claude.ai artifact preview specifically:** even once your backend is
live, fetch requests from *inside the Claude.ai artifact preview panel* may be blocked
by that preview's own sandbox, regardless of your backend's CORS settings — that
sandbox restricts outbound network calls for security reasons. This works normally
once you copy the component into your own hosted site (Next.js, Vite, plain React,
etc.) — it's only the in-chat preview iframe that's restricted.

## Project layout

```
src/
  server.js            Express app + routes
  poller.js             Cron scheduling, orchestrates the two rolling pollers
  dailySnapshot.js       Once-a-day capture of "today's trending" + history
  cache.js               In-memory + on-disk cache for the rolling pollers
  util.js                 Shared helpers (id hashing, relative time, cleanup)
  pollOnce.js            One-off test script (npm run poll-once)
  providers/
    newsdata.js          NewsData.io adapter
    gnews.js               GNews.io adapter (alternative)
    googleTrends.js        Google Daily Trends RSS adapter
data/
  trending.json          Rolling cache, written at runtime (git-ignore this)
  today.json              Today's captured snapshot (git-ignore this)
  history/YYYY-MM-DD.json Past days' snapshots (git-ignore this)
```
