// Adapter for https://gnews.io — alternative to NewsData.io if you'd rather use that
// free tier instead (100 requests/day). Same defensive-mapping approach as newsdata.js:
// verify field names against GNews's current docs if their response shape changes.

import { clean, relativeTime, stableId } from "../util.js";

const ENDPOINT = "https://gnews.io/api/v4/top-headlines";

const CATEGORY_LABELS = {
  politics: "Politics",
  business: "Business",
  sports: "Sports",
  entertainment: "Entertainment",
  health: "Health",
  technology: "Business",
  general: "Politics",
};

function mapArticle(article, category) {
  const title = clean(article.title, 140);
  if (!title) return null;
  return {
    id: stableId(title + "|" + (article.source?.name || "")),
    category: CATEGORY_LABELS[category] || "Business",
    title,
    summary: clean(article.description || "Full story available at the source link.", 200),
    time: relativeTime(article.publishedAt),
    publishedAt: article.publishedAt || null,
    url: article.url || null,
    source: article.source?.name || "News",
  };
}

/**
 * GNews's top-headlines endpoint takes ONE category per request, so we fan out
 * across the configured categories and merge the results.
 * @param {{apiKey: string, country: string, categories: string[]}} opts
 */
export async function fetchGnews({ apiKey, country, categories }) {
  if (!apiKey) throw new Error("NEWS_API_KEY is not set");
  const results = [];
  for (const category of categories) {
    const params = new URLSearchParams({
      apikey: apiKey,
      country,
      lang: "en",
      category,
      max: "10",
    });
    const res = await fetch(`${ENDPOINT}?${params.toString()}`);
    if (!res.ok) {
      const body = await res.text().catch(() => "");
      console.warn(`GNews request failed for category "${category}" (${res.status}): ${body.slice(0, 200)}`);
      continue; // one bad category shouldn't kill the whole poll
    }
    const json = await res.json();
    const articles = Array.isArray(json.articles) ? json.articles : [];
    results.push(...articles.map((a) => mapArticle(a, category)).filter(Boolean));
  }
  return results;
}
