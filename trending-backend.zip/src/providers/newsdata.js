// Adapter for https://newsdata.io — free tier covers Kenya (country=ke) with category
// filters. Field names below match NewsData's documented "latest news" response as of
// this writing; NewsData (like any third-party API) can change its schema, so this is
// written defensively (optional chaining + fallbacks) rather than assuming every field
// is always present. If NewsData changes its response shape, check their docs and
// adjust the `mapArticle` function only — nothing else in the backend needs to change.

import { clean, relativeTime, stableId } from "../util.js";

const ENDPOINT = "https://newsdata.io/api/1/news";

// Map NewsData's category strings onto the categories the frontend already knows about.
const CATEGORY_LABELS = {
  politics: "Politics",
  business: "Business",
  sports: "Sports",
  entertainment: "Entertainment",
  health: "Health",
  technology: "Business", // no dedicated Tech card on the frontend yet — folded into Business
  world: "Politics",
  top: "Politics",
};

function mapArticle(article) {
  const rawCategory = Array.isArray(article.category) ? article.category[0] : article.category;
  const category = CATEGORY_LABELS[rawCategory] || "Business";
  const title = clean(article.title, 140);
  if (!title) return null;
  return {
    id: stableId(title + "|" + (article.source_id || "")),
    category,
    title,
    summary: clean(article.description || article.content || "Full story available at the source link.", 200),
    time: relativeTime(article.pubDate),
    publishedAt: article.pubDate || null,
    url: article.link || null,
    source: article.source_id || "News",
  };
}

/**
 * Fetch the latest Kenya headlines from NewsData.io across the configured categories.
 * @param {{apiKey: string, country: string, categories: string[]}} opts
 * @returns {Promise<Array>} normalized story objects
 */
export async function fetchNewsdata({ apiKey, country, categories }) {
  if (!apiKey) throw new Error("NEWS_API_KEY is not set");
  const params = new URLSearchParams({
    apikey: apiKey,
    country,
    language: "en",
    category: categories.join(","),
  });
  const res = await fetch(`${ENDPOINT}?${params.toString()}`);
  if (!res.ok) {
    const body = await res.text().catch(() => "");
    throw new Error(`NewsData request failed (${res.status}): ${body.slice(0, 200)}`);
  }
  const json = await res.json();
  const articles = Array.isArray(json.results) ? json.results : [];
  return articles.map(mapArticle).filter(Boolean);
}
