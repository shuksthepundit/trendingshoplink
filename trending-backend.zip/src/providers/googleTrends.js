// Google publishes a "Daily Search Trends" RSS feed per country — this is a real,
// intentionally-served XML feed (not the search-results HTML page), so a server-side
// fetch of it is a legitimate, ToS-friendly way to get genuine trending-search topics.
// It is NOT Twitter/X trends — label it honestly in the UI as "Trending Searches".
//
// If Google changes or retires this feed, this is the one file to update; everything
// downstream just consumes whatever normalized stories this function returns.

import { XMLParser } from "fast-xml-parser";
import { clean, relativeTime, stableId } from "../util.js";

function feedUrl(geo) {
  return `https://trends.google.com/trending/rss?geo=${encodeURIComponent(geo)}`;
}

export async function fetchGoogleTrends({ geo }) {
  const res = await fetch(feedUrl(geo), {
    headers: { "User-Agent": "Mozilla/5.0 (compatible; TrendingKenyaBot/1.0)" },
  });
  if (!res.ok) {
    throw new Error(`Google Trends feed request failed (${res.status})`);
  }
  const xml = await res.text();
  const parser = new XMLParser({ ignoreAttributes: false });
  const parsed = parser.parse(xml);

  const items = parsed?.rss?.channel?.item;
  const list = Array.isArray(items) ? items : items ? [items] : [];

  return list
    .map((item) => {
      const title = clean(item.title, 120);
      if (!title) return null;
      // approx_traffic (e.g. "20,000+") is a rough popularity signal from the feed
      const traffic = clean(item["ht:approx_traffic"] || "", 20).replace(/[^0-9]/g, "");
      return {
        id: stableId("trend|" + title),
        category: "Trending Searches",
        title,
        summary: "A widely-searched topic right now — tap through to see what people are asking.",
        time: relativeTime(item.pubDate),
        publishedAt: item.pubDate || null,
        url: item.link || null,
        source: "Google Trends",
        approxSearches: traffic ? Number(traffic) : null,
      };
    })
    .filter(Boolean);
}
