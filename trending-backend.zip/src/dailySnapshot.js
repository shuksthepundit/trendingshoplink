// Separate from the rolling poller cache (poller.js/cache.js), which refreshes every
// 30–60 minutes to keep individual stories fresh. This module captures ONE official
// snapshot per calendar day — "what was trending today" — the way a real trends
// site publishes a daily digest, and keeps a dated history so past days aren't lost.

import { readFile, writeFile, mkdir, readdir } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import cron from "node-cron";
import { getCombinedStories } from "./cache.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.join(__dirname, "..", "data");
const HISTORY_DIR = path.join(DATA_DIR, "history");
const TODAY_FILE = path.join(DATA_DIR, "today.json");

/** "YYYY-MM-DD" in the given IANA timezone (default Africa/Nairobi), so "today"
 *  means the same thing regardless of which timezone the server itself runs in. */
function todayKey(tz) {
  return new Intl.DateTimeFormat("en-CA", { timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
}

let todayState = { date: null, capturedAt: null, stories: [] };

export async function loadTodayFromDisk() {
  try {
    const raw = await readFile(TODAY_FILE, "utf8");
    todayState = JSON.parse(raw);
    console.log(`[daily] loaded existing snapshot for ${todayState.date} (${todayState.stories?.length || 0} stories)`);
  } catch {
    console.log("[daily] no existing snapshot yet");
  }
}

async function persistToday() {
  await mkdir(DATA_DIR, { recursive: true });
  await writeFile(TODAY_FILE, JSON.stringify(todayState, null, 2), "utf8");
}

async function persistHistory(dateKey, snapshot) {
  await mkdir(HISTORY_DIR, { recursive: true });
  await writeFile(path.join(HISTORY_DIR, `${dateKey}.json`), JSON.stringify(snapshot, null, 2), "utf8");
}

/** Takes a fresh daily snapshot of whatever is currently in the rolling poller
 *  cache and files it under today's date, both as "today.json" (what the API
 *  serves) and as a dated record under history/ (so it isn't overwritten
 *  tomorrow). Safe to call more than once in a day — later calls in the same
 *  day just re-capture and overwrite that day's file, they don't duplicate it. */
export async function captureDailySnapshot(tz) {
  const dateKey = todayKey(tz);
  const stories = getCombinedStories();
  todayState = { date: dateKey, capturedAt: new Date().toISOString(), stories };
  await persistToday();
  await persistHistory(dateKey, todayState);
  console.log(`[daily] captured ${stories.length} stories for ${dateKey}`);
  return todayState;
}

/** What the frontend actually reads. If nobody has captured a snapshot for
 *  today yet (server just started, or the scheduled time hasn't hit yet),
 *  it captures on the spot — so "today's trending" is never stale from
 *  yesterday just because the cron hasn't fired.
 *
 *  If the rolling poller cache is still empty (e.g. this fires seconds after
 *  boot, before the very first news/trends fetch has resolved), it does NOT
 *  lock in a permanently-empty day — it returns an uncaptured placeholder and
 *  tries again on the next request, once real stories exist to capture. */
export async function getTodaySnapshot(tz) {
  const dateKey = todayKey(tz);
  if (todayState.date === dateKey && todayState.stories.length > 0) {
    return todayState;
  }
  const stories = getCombinedStories();
  if (stories.length === 0) {
    return { date: dateKey, capturedAt: null, stories: [] };
  }
  return captureDailySnapshot(tz);
}

export async function getHistorySnapshot(dateKey) {
  try {
    const raw = await readFile(path.join(HISTORY_DIR, `${dateKey}.json`), "utf8");
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

export async function listHistoryDates() {
  try {
    const files = await readdir(HISTORY_DIR);
    return files.filter((f) => f.endsWith(".json")).map((f) => f.replace(".json", "")).sort().reverse();
  } catch {
    return [];
  }
}

/** Registers the once-a-day cron job. Defaults to 06:00 Africa/Nairobi — after
 *  the news/trends pollers have had a chance to run at least once, so the
 *  morning snapshot reflects overnight developments rather than stale data
 *  from before midnight. */
export function startDailySnapshotSchedule({ cronExpr, tz }) {
  cron.schedule(cronExpr, () => captureDailySnapshot(tz), { timezone: tz });
  console.log(`[daily] scheduled daily capture "${cronExpr}" (${tz})`);
}
