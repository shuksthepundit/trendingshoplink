// Small, dependency-free helpers shared by the provider adapters.

/** Deterministic short id from a string (title+source), so the same story
 *  polled twice in a row doesn't get duplicated in the cache. */
export function stableId(input) {
  let h = 0;
  for (let i = 0; i < input.length; i++) {
    h = (h << 5) - h + input.charCodeAt(i);
    h |= 0;
  }
  return "s" + Math.abs(h).toString(36);
}

/** "3h ago" / "2d ago" style relative time from an ISO date string. */
export function relativeTime(isoString) {
  if (!isoString) return "Recently";
  const then = new Date(isoString).getTime();
  if (Number.isNaN(then)) return "Recently";
  const diffMs = Date.now() - then;
  const mins = Math.round(diffMs / 60000);
  if (mins < 1) return "Just now";
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.round(hours / 24);
  return `${days}d ago`;
}

/** Trim + collapse whitespace, and hard-cap length so a stray huge field
 *  from an API response can't blow up the payload. */
export function clean(str, maxLen = 220) {
  if (!str) return "";
  const s = String(str).replace(/\s+/g, " ").trim();
  return s.length > maxLen ? s.slice(0, maxLen - 1) + "…" : s;
}
