import cron from "node-cron";
import { fetchNewsdata } from "./providers/newsdata.js";
import { fetchGnews } from "./providers/gnews.js";
import { fetchGoogleTrends } from "./providers/googleTrends.js";
import { setNewsStories, setTrendStories, recordNewsError, recordTrendsError } from "./cache.js";

function newsConfig() {
  return {
    apiKey: process.env.NEWS_API_KEY,
    country: process.env.NEWS_COUNTRY || "ke",
    categories: (process.env.NEWS_CATEGORIES || "politics,business,sports,entertainment,health")
      .split(",").map((c) => c.trim()).filter(Boolean),
  };
}

export async function pollNewsOnce() {
  const provider = (process.env.NEWS_PROVIDER || "newsdata").toLowerCase();
  console.log(`[poller:news] polling via "${provider}"...`);
  try {
    const fetcher = provider === "gnews" ? fetchGnews : fetchNewsdata;
    const stories = await fetcher(newsConfig());
    await setNewsStories(stories);
    console.log(`[poller:news] cached ${stories.length} stories`);
  } catch (err) {
    await recordNewsError(err);
  }
}

export async function pollTrendsOnce() {
  if (String(process.env.ENABLE_TRENDS_FEED).toLowerCase() === "false") return;
  console.log("[poller:trends] polling Google Daily Trends...");
  try {
    const stories = await fetchGoogleTrends({ geo: process.env.TRENDS_GEO || "KE" });
    await setTrendStories(stories);
    console.log(`[poller:trends] cached ${stories.length} trending searches`);
  } catch (err) {
    await recordTrendsError(err);
  }
}

/** Registers the two cron schedules and kicks off an immediate first poll of each,
 *  so the cache isn't empty while waiting for the first scheduled tick. */
export function startPolling() {
  const newsCron = process.env.POLL_CRON_NEWS || "*/30 * * * *";
  const trendsCron = process.env.POLL_CRON_TRENDS || "0 * * * *";

  pollNewsOnce();
  pollTrendsOnce();

  cron.schedule(newsCron, pollNewsOnce);
  cron.schedule(trendsCron, pollTrendsOnce);

  console.log(`[poller] scheduled — news "${newsCron}", trends "${trendsCron}"`);
}
