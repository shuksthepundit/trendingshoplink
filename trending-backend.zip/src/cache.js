import { readFile, writeFile, mkdir } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.join(__dirname, "..", "data");
const CACHE_FILE = path.join(DATA_DIR, "trending.json");

// News and trending-searches are polled on separate schedules, so they're kept in
// separate buckets and only combined when someone actually reads the cache.
let state = {
  newsStories: [],
  trendStories: [],
  lastNewsPoll: null,
  lastTrendsPoll: null,
  lastNewsError: null,
  lastTrendsError: null,
};

export async function loadCacheFromDisk() {
  try {
    const raw = await readFile(CACHE_FILE, "utf8");
    state = { ...state, ...JSON.parse(raw) };
    console.log(`[cache] loaded ${state.newsStories.length} news + ${state.trendStories.length} trend items from disk`);
  } catch {
    console.log("[cache] no existing cache file yet — starting empty");
  }
}

async function persist() {
  try {
    await mkdir(DATA_DIR, { recursive: true });
    await writeFile(CACHE_FILE, JSON.stringify(state, null, 2), "utf8");
  } catch (err) {
    console.warn("[cache] failed to persist to disk:", err.message);
  }
}

export async function setNewsStories(stories) {
  state.newsStories = stories.slice(0, 40);
  state.lastNewsPoll = new Date().toISOString();
  state.lastNewsError = null;
  await persist();
}

export async function setTrendStories(stories) {
  state.trendStories = stories.slice(0, 20);
  state.lastTrendsPoll = new Date().toISOString();
  state.lastTrendsError = null;
  await persist();
}

export async function recordNewsError(err) {
  state.lastNewsError = { message: err.message, at: new Date().toISOString() };
  console.error("[poller:news] error:", err.message);
  await persist();
}

export async function recordTrendsError(err) {
  state.lastTrendsError = { message: err.message, at: new Date().toISOString() };
  console.error("[poller:trends] error:", err.message);
  await persist();
}

/** Combined view the API route serves: news stories first, then trending searches. */
export function getCombinedStories() {
  return [...state.newsStories, ...state.trendStories];
}

export function getMeta() {
  const { newsStories, trendStories, ...meta } = state;
  return { ...meta, newsCount: newsStories.length, trendCount: trendStories.length };
}
