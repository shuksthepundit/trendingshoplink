// Run with: npm run poll-once
// Quick way to check your API key and see raw results before wiring up the full server.
import "dotenv/config";
import { loadCacheFromDisk, getCombinedStories } from "./cache.js";
import { pollNewsOnce, pollTrendsOnce } from "./poller.js";

await loadCacheFromDisk();
await pollNewsOnce();
await pollTrendsOnce();
console.log(JSON.stringify(getCombinedStories(), null, 2));
