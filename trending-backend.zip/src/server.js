import "dotenv/config";
import express from "express";
import cors from "cors";
import { loadCacheFromDisk, getCombinedStories, getMeta } from "./cache.js";
import { startPolling } from "./poller.js";
import {
  loadTodayFromDisk, getTodaySnapshot, getHistorySnapshot, listHistoryDates, startDailySnapshotSchedule,
} from "./dailySnapshot.js";

const app = express();
const PORT = process.env.PORT || 8787;
const DAILY_TZ = process.env.DAILY_SNAPSHOT_TZ || "Africa/Nairobi";
const DAILY_CRON = process.env.DAILY_SNAPSHOT_CRON || "0 6 * * *"; // 06:00 daily, server's configured timezone

const allowedOrigins = (process.env.ALLOWED_ORIGINS || "*").split(",").map((s) => s.trim());
app.use(cors({
  origin: allowedOrigins.includes("*") ? true : allowedOrigins,
}));

// GET /api/trending — the rolling cache, refreshed every 30–60 min by the pollers.
// Use this for "what's trending right now."
app.get("/api/trending", (req, res) => {
  const meta = getMeta();
  res.json({
    stories: getCombinedStories(),
    lastNewsPoll: meta.lastNewsPoll,
    lastTrendsPoll: meta.lastTrendsPoll,
    lastNewsError: meta.lastNewsError,
    lastTrendsError: meta.lastTrendsError,
  });
});

// GET /api/trending/today — the ONE official snapshot captured for today (see
// dailySnapshot.js). Auto-captures on first request of a new day if the
// scheduled job hasn't fired yet, so this is never empty. Use this for
// "today's trending" as a published, stable daily list.
app.get("/api/trending/today", async (req, res) => {
  const snapshot = await getTodaySnapshot(DAILY_TZ);
  res.json(snapshot);
});

// GET /api/trending/history?date=YYYY-MM-DD — a past day's captured snapshot.
// GET /api/trending/history (no query)     — list of dates with a snapshot on file.
app.get("/api/trending/history", async (req, res) => {
  const { date } = req.query;
  if (date) {
    const snapshot = await getHistorySnapshot(date);
    if (!snapshot) return res.status(404).json({ error: `No snapshot captured for ${date}` });
    return res.json(snapshot);
  }
  res.json({ dates: await listHistoryDates() });
});

// GET /api/health — for uptime checks / your host's health-check probe.
app.get("/api/health", (req, res) => {
  const meta = getMeta();
  res.json({ ok: true, dailySnapshotSchedule: DAILY_CRON, dailySnapshotTz: DAILY_TZ, ...meta });
});

async function main() {
  await loadCacheFromDisk();
  await loadTodayFromDisk();
  startPolling();
  startDailySnapshotSchedule({ cronExpr: DAILY_CRON, tz: DAILY_TZ });
  app.listen(PORT, () => {
    console.log(`[server] Trending Kenya backend listening on port ${PORT}`);
  });
}

main();
